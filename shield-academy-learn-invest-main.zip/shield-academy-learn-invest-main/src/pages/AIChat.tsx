 import { useState, useRef, useEffect, useCallback } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
 import { Send, Bot, User, Sparkles, AlertCircle } from "lucide-react";
 import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
}

 const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;
 
 const initialMessage: Message = {
   id: 1,
   role: "assistant",
   content:
     "Привет! Я Shieldy — твой AI-наставник по инвестициям. 🛡️\n\nМогу объяснить сложные финансовые термины простым языком, помочь разобраться в рисках и ответить на любые вопросы об инвестициях.\n\nО чём хочешь узнать?",
 };

const suggestedQuestions = [
  "Что такое акции?",
  "Как начать инвестировать?",
  "Что такое криптовалюта?",
  "Как распознать мошенников?",
];


const AIChat = () => {
   const [messages, setMessages] = useState<Message[]>([initialMessage]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
   const abortControllerRef = useRef<AbortController | null>(null);
   const streamChat = useCallback(async (
     chatMessages: { role: string; content: string }[],
     onDelta: (delta: string) => void,
     onDone: () => void
   ) => {
     abortControllerRef.current = new AbortController();
     
     const resp = await fetch(CHAT_URL, {
       method: "POST",
       headers: {
         "Content-Type": "application/json",
         Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
       },
       body: JSON.stringify({ messages: chatMessages }),
       signal: abortControllerRef.current.signal,
     });
 
     if (!resp.ok) {
       const errorData = await resp.json().catch(() => ({}));
       if (resp.status === 429) {
         toast.error("Слишком много запросов. Подожди немного.");
       } else if (resp.status === 402) {
         toast.error("Лимит запросов исчерпан.");
       } else {
         toast.error(errorData.error || "Ошибка при обращении к AI");
       }
       throw new Error(errorData.error || "Failed to start stream");
     }
 
     if (!resp.body) throw new Error("No response body");
 
     const reader = resp.body.getReader();
     const decoder = new TextDecoder();
     let textBuffer = "";
     let streamDone = false;
 
     while (!streamDone) {
       const { done, value } = await reader.read();
       if (done) break;
       textBuffer += decoder.decode(value, { stream: true });
 
       let newlineIndex: number;
       while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
         let line = textBuffer.slice(0, newlineIndex);
         textBuffer = textBuffer.slice(newlineIndex + 1);
 
         if (line.endsWith("\r")) line = line.slice(0, -1);
         if (line.startsWith(":") || line.trim() === "") continue;
         if (!line.startsWith("data: ")) continue;
 
         const jsonStr = line.slice(6).trim();
         if (jsonStr === "[DONE]") {
           streamDone = true;
           break;
         }
 
         try {
           const parsed = JSON.parse(jsonStr);
           const content = parsed.choices?.[0]?.delta?.content as string | undefined;
           if (content) onDelta(content);
         } catch {
           textBuffer = line + "\n" + textBuffer;
           break;
         }
       }
     }
 
     onDone();
   }, []);
 

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

   const handleSend = useCallback(async (text: string = input) => {
    if (!text.trim()) return;
     if (isTyping) return;

    const userMessage: Message = {
      id: Date.now(),
      role: "user",
      content: text,
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

     let assistantContent = "";
     const assistantId = Date.now() + 1;

     const upsertAssistant = (nextChunk: string) => {
       assistantContent += nextChunk;
       setMessages(prev => {
         const last = prev[prev.length - 1];
         if (last?.role === "assistant" && last.id === assistantId) {
           return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: assistantContent } : m));
         }
         return [...prev, { id: assistantId, role: "assistant", content: assistantContent }];
       });
    };

     const chatHistory = [...messages, userMessage].map(m => ({
       role: m.role,
       content: m.content,
     }));
 
     try {
       await streamChat(
         chatHistory,
         (chunk) => upsertAssistant(chunk),
         () => setIsTyping(false)
       );
     } catch (e) {
       console.error("Chat error:", e);
       setIsTyping(false);
       if (!assistantContent) {
         setMessages(prev => [
           ...prev,
           {
             id: assistantId,
             role: "assistant",
             content: "Извини, произошла ошибка. Попробуй ещё раз! 🛡️",
           },
         ]);
       }
     }
   }, [input, isTyping, messages, streamChat]);

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-8rem)]">
        {/* Header */}
        <div className="flex items-center gap-3 py-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Bot className="w-6 h-6 text-primary" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-success rounded-full border-2 border-background" />
          </div>
          <div>
            <h1 className="text-lg font-bold">AI Shieldy</h1>
            <p className="text-xs text-muted-foreground">Онлайн</p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 py-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3 animate-fade-in",
                message.role === "user" ? "flex-row-reverse" : ""
              )}
            >
              <div
                className={cn(
                  "w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center",
                  message.role === "user"
                    ? "bg-primary/20"
                    : "bg-primary/10"
                )}
              >
                {message.role === "user" ? (
                  <User className="w-4 h-4 text-primary" />
                ) : (
                  <Bot className="w-4 h-4 text-primary" />
                )}
              </div>
              <div
                className={cn(
                  "max-w-[80%] rounded-2xl p-4",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground rounded-tr-md"
                    : "bg-card border border-border/50 rounded-tl-md"
                )}
              >
                <p className="text-sm whitespace-pre-line">{message.content}</p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3 animate-fade-in">
              <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
                <Bot className="w-4 h-4 text-primary" />
              </div>
              <div className="bg-card border border-border/50 rounded-2xl rounded-tl-md p-4">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length === 1 && (
          <div className="py-2">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Популярные вопросы</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question) => (
                <button
                  key={question}
                  onClick={() => handleSend(question)}
                  className="px-3 py-2 bg-secondary rounded-xl text-xs hover:bg-secondary/80 transition-colors"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="py-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
              placeholder="Задай вопрос..."
              className="flex-1 bg-card border border-border/50 rounded-xl px-4 py-3 text-sm outline-none focus:border-primary/50 transition-colors"
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isTyping}
              className="btn-gold w-12 h-12 rounded-xl flex items-center justify-center disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default AIChat;
