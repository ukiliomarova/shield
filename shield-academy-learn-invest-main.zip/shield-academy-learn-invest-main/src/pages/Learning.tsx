import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { BookOpen, CheckCircle, Circle, ChevronRight, Lightbulb, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface Lesson {
  id: number;
  title: string;
  description: string;
  duration: string;
  completed: boolean;
  content: string;
}

const lessons: Lesson[] = [
  {
    id: 1,
    title: "Что такое инвестиции?",
    description: "Основы инвестирования для начинающих",
    duration: "4 мин",
    completed: true,
    content: `Инвестиции — это вложение денег или других ресурсов с целью получения прибыли в будущем.

Представь, что ты посадил яблоню. Сначала ты тратишь время и усилия, но через несколько лет получаешь урожай яблок каждый год.

Основные виды инвестиций:
• Акции — доли в компаниях
• Облигации — займы компаниям или государству
• Криптовалюты — цифровые валюты
• Недвижимость — дома и квартиры

Главное правило: никогда не инвестируй деньги, которые не можешь позволить себе потерять.`,
  },
  {
    id: 2,
    title: "Что такое диверсификация?",
    description: "Почему важно распределять риски",
    duration: "5 мин",
    completed: false,
    content: `Диверсификация — это стратегия распределения инвестиций между разными активами.

Народная мудрость: "Не клади все яйца в одну корзину"

Почему это важно?
Если все деньги вложить в одну компанию и она обанкротится — ты потеряешь всё. Но если распределить между 10 компаниями, потеря одной не будет катастрофой.

Как диверсифицировать:
• По типам активов (акции, облигации, криптовалюта)
• По странам (США, Казахстан, Европа)
• По секторам (технологии, здравоохранение, энергетика)

Пример: Вместо 100% в Bitcoin, раздели: 40% акции, 30% облигации, 20% криптовалюта, 10% золото.`,
  },
  {
    id: 3,
    title: "Риск и доходность",
    description: "Связь между риском и прибылью",
    duration: "6 мин",
    completed: false,
    content: `Главное правило инвестиций: чем выше потенциальная доходность, тем выше риск.

Уровни риска:
🟢 Низкий риск — банковские депозиты, гос. облигации (2-5% годовых)
🟡 Средний риск — акции крупных компаний (8-15% годовых)
🔴 Высокий риск — криптовалюты, стартапы (от -100% до +1000%)

Важно понимать:
• Высокий риск ≠ гарантированная высокая прибыль
• Низкий риск ≠ отсутствие риска
• Диверсификация снижает общий риск портфеля

Правило 100: Возьми 100 и вычти свой возраст. Результат — процент портфеля в рискованных активах. Для 15-летнего: 100-15=85% можно держать в акциях.`,
  },
  {
    id: 4,
    title: "Что такое акции?",
    description: "Как работает владение компанией",
    duration: "5 мин",
    completed: false,
    content: `Акция — это маленькая доля владения компанией.

Если компания разделена на 1000 акций и ты купил 10, то тебе принадлежит 1% компании.

Как заработать на акциях:
1. Рост цены — купил за $100, продал за $150 = +$50 прибыли
2. Дивиденды — компания делится частью прибыли с акционерами

Пример: Если бы ты купил 1 акцию Apple в 2010 году за $10, сегодня она стоила бы около $180.

Где покупать акции:
• Брокеры (Halyk Finance, Freedom Finance)
• Биржи (KASE в Казахстане, NYSE в США)

Важно: покупай акции только тех компаний, бизнес которых ты понимаешь.`,
  },
];

interface QuizQuestion {
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

const quizQuestions: QuizQuestion[] = [
  {
    question: "Что такое диверсификация?",
    options: [
      "Вложение всех денег в одну компанию",
      "Распределение инвестиций между разными активами",
      "Продажа всех активов",
      "Покупка только криптовалюты",
    ],
    correct: 1,
    explanation: "Диверсификация — это стратегия распределения инвестиций для снижения рисков.",
  },
  {
    question: "Какой актив обычно имеет самый высокий риск?",
    options: [
      "Банковский депозит",
      "Государственные облигации",
      "Криптовалюта",
      "Золото",
    ],
    correct: 2,
    explanation: "Криптовалюты очень волатильны и могут как вырасти, так и упасть на 50%+ за день.",
  },
  {
    question: "Что такое дивиденды?",
    options: [
      "Плата за покупку акций",
      "Часть прибыли компании, которую получают акционеры",
      "Налог на инвестиции",
      "Комиссия брокера",
    ],
    correct: 1,
    explanation: "Дивиденды — это часть прибыли компании, которую она выплачивает своим акционерам.",
  },
];

const Learning = () => {
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);

  const handleAnswerSelect = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    setShowExplanation(true);
    if (index === quizQuestions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      // Quiz completed
      setShowQuiz(false);
      setSelectedLesson(null);
      setCurrentQuestion(0);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  if (showQuiz) {
    const question = quizQuestions[currentQuestion];
    return (
      <AppLayout>
        <div className="py-4 space-y-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowQuiz(false)}
              className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold">Тест</h1>
              <p className="text-sm text-muted-foreground">
                Вопрос {currentQuestion + 1} из {quizQuestions.length}
              </p>
            </div>
          </div>

          {/* Progress */}
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
            />
          </div>

          {/* Question */}
          <div className="bg-card rounded-2xl p-5 border border-border/50">
            <h2 className="text-lg font-semibold mb-6">{question.question}</h2>

            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(index)}
                  className={cn(
                    "w-full p-4 rounded-xl text-left transition-all duration-300 border",
                    selectedAnswer === null
                      ? "bg-secondary/50 border-border/50 hover:border-primary/50"
                      : index === question.correct
                      ? "bg-success/10 border-success"
                      : index === selectedAnswer
                      ? "bg-destructive/10 border-destructive"
                      : "bg-secondary/50 border-border/50 opacity-50"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center font-semibold text-sm">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span className="text-sm">{option}</span>
                  </div>
                </button>
              ))}
            </div>

            {showExplanation && (
              <div className="mt-6 p-4 rounded-xl bg-primary/10 border border-primary/30 animate-fade-in">
                <div className="flex items-start gap-2">
                  <Lightbulb className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-sm">{question.explanation}</p>
                </div>
              </div>
            )}
          </div>

          {showExplanation && (
            <button
              onClick={nextQuestion}
              className="btn-gold w-full py-3 rounded-xl flex items-center justify-center gap-2"
            >
              {currentQuestion < quizQuestions.length - 1 ? "Следующий вопрос" : `Завершить (+${score * 50} XP)`}
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </AppLayout>
    );
  }

  if (selectedLesson) {
    return (
      <AppLayout>
        <div className="py-4 space-y-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSelectedLesson(null)}
              className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold">{selectedLesson.title}</h1>
              <p className="text-sm text-muted-foreground">{selectedLesson.duration}</p>
            </div>
          </div>

          <div className="bg-card rounded-2xl p-5 border border-border/50">
            <div className="prose prose-invert prose-sm max-w-none">
              {selectedLesson.content.split('\n\n').map((paragraph, index) => (
                <p key={index} className="text-sm text-foreground/90 mb-4 whitespace-pre-line">
                  {paragraph}
                </p>
              ))}
            </div>
          </div>

          <button
            onClick={() => setShowQuiz(true)}
            className="btn-gold w-full py-3 rounded-xl flex items-center justify-center gap-2"
          >
            Пройти тест
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="py-4 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Обучение</h1>
          <p className="text-sm text-muted-foreground">
            Изучай основы инвестиций
          </p>
        </div>

        {/* Lessons list */}
        <div className="space-y-3">
          {lessons.map((lesson) => (
            <button
              key={lesson.id}
              onClick={() => setSelectedLesson(lesson)}
              className="w-full flex items-center gap-4 p-4 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-all duration-300 text-left"
            >
              <div className="flex-shrink-0">
                {lesson.completed ? (
                  <CheckCircle className="w-6 h-6 text-success" />
                ) : (
                  <Circle className="w-6 h-6 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm">{lesson.title}</h3>
                <p className="text-xs text-muted-foreground truncate">
                  {lesson.description}
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <BookOpen className="w-4 h-4" />
                <span>{lesson.duration}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Learning;
