import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Shield, AlertTriangle, CheckCircle, X, ChevronRight, RotateCcw, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";

interface ScamScenario {
  id: number;
  title: string;
  description: string;
  isScam: boolean;
  explanation: string;
}

const scenarios: ScamScenario[] = [
  {
    id: 1,
    title: "Инвестиционное предложение",
    description: "Вам предлагают вложить $100 и получить $300 через 24 часа. Гарантированная прибыль 200%!",
    isScam: true,
    explanation: "Это классическая схема мошенничества. Никто не может гарантировать такую прибыль за сутки. Законные инвестиции приносят 5-15% в ГОД, а не 200% за день.",
  },
  {
    id: 2,
    title: "Криптопроект",
    description: "Новая криптовалюта обещает рост в 1000 раз за месяц. Основатели анонимны, белой бумаги нет.",
    isScam: true,
    explanation: "Анонимные создатели и отсутствие документации — главные признаки скама. Легальные проекты всегда прозрачны о своей команде и планах.",
  },
  {
    id: 3,
    title: "Брокерская компания",
    description: "Freedom Finance KZ предлагает открыть брокерский счёт. Компания лицензирована Нацбанком РК.",
    isScam: false,
    explanation: "Это легальный брокер с лицензией регулятора. Наличие лицензии можно проверить на сайте Нацбанка. Это надёжный способ инвестирования.",
  },
  {
    id: 4,
    title: "Telegram-канал",
    description: "Канал с 'сигналами' обещает 90% успешных сделок. Подписка стоит $500 в месяц.",
    isScam: true,
    explanation: "Никто не может гарантировать 90% успешных сделок. Такие каналы часто показывают только удачные сделки, скрывая убытки.",
  },
  {
    id: 5,
    title: "Банковский депозит",
    description: "Kaspi Bank предлагает депозит под 14% годовых с гарантией вклада от государства.",
    isScam: false,
    explanation: "Банковские депозиты в Казахстане застрахованы государством до определённой суммы. Это безопасный способ сбережения денег.",
  },
  {
    id: 6,
    title: "Сообщение в WhatsApp",
    description: "Незнакомец пишет о срочной возможности заработать. Нужно перевести деньги на 'инвестиционный счёт'.",
    isScam: true,
    explanation: "Легальные компании не ищут клиентов через случайные сообщения. Никогда не переводите деньги незнакомцам.",
  },
  {
    id: 7,
    title: "ETF на бирже",
    description: "Покупка ETF SPY на американскую экономику через лицензированного брокера.",
    isScam: false,
    explanation: "ETF — это легальный инвестиционный инструмент, торгуемый на бирже. SPY отслеживает 500 крупнейших компаний США.",
  },
  {
    id: 8,
    title: "Финансовая пирамида",
    description: "Компания платит бонусы за привлечение новых участников. Доход зависит от количества приведённых людей.",
    isScam: true,
    explanation: "Это классическая финансовая пирамида. Когда доход зависит от привлечения новых людей, а не от продажи реального продукта — это мошенничество.",
  },
];

const AntiScam = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [swipeDirection, setSwipeDirection] = useState<"left" | "right" | null>(null);

  const currentScenario = scenarios[currentIndex];
  const progress = ((currentIndex + 1) / scenarios.length) * 100;

  const handleAnswer = (answer: boolean) => {
    if (selectedAnswer !== null) return;
    
    setSelectedAnswer(answer);
    setSwipeDirection(answer ? "right" : "left");
    setShowExplanation(true);
    
    if (answer === currentScenario.isScam) {
      setScore(score + 1);
    }
  };

  const nextScenario = () => {
    if (currentIndex < scenarios.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setSwipeDirection(null);
    } else {
      setCompleted(true);
    }
  };

  const restart = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setCompleted(false);
    setSwipeDirection(null);
  };

  if (completed) {
    const percentage = (score / scenarios.length) * 100;
    let title = "";
    let message = "";

    if (percentage >= 80) {
      title = "Отлично!";
      message = "Ты настоящий анти-скам эксперт!";
    } else if (percentage >= 60) {
      title = "Хороший результат!";
      message = "Продолжай учиться распознавать мошенников.";
    } else {
      title = "Есть над чем работать";
      message = "Рекомендуем пройти обучающие уроки о мошенничестве.";
    }

    return (
      <AppLayout>
        <div className="py-4 flex flex-col items-center justify-center min-h-[60vh] text-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6 animate-pulse-gold">
            <Trophy className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-2">{title}</h1>
          <p className="text-muted-foreground mb-6">{message}</p>
          
          <div className="bg-card rounded-2xl p-6 border border-border/50 w-full mb-6">
            <p className="text-4xl font-bold text-primary mb-2">
              {score}/{scenarios.length}
            </p>
            <p className="text-sm text-muted-foreground">правильных ответов</p>
            <div className="mt-4 h-3 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-1000"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          <p className="text-sm text-muted-foreground mb-4">
            +{score * 25} XP заработано
          </p>

          <button
            onClick={restart}
            className="btn-gold w-full py-4 rounded-xl flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-5 h-5" />
            Пройти заново
          </button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="py-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Anti-Scam Lab</h1>
            <p className="text-sm text-muted-foreground">
              Распознай мошенничество
            </p>
          </div>
          <div className="bg-card px-3 py-1.5 rounded-full border border-border/50">
            <span className="text-sm font-medium">
              {currentIndex + 1}/{scenarios.length}
            </span>
          </div>
        </div>

        {/* Progress */}
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Card */}
        <div
          className={cn(
            "relative bg-card rounded-2xl p-6 border border-border/50 transition-all duration-300",
            swipeDirection === "left" && "border-destructive/50",
            swipeDirection === "right" && "border-success/50"
          )}
        >
          {/* Glow */}
          <div
            className={cn(
              "absolute -inset-1 rounded-2xl opacity-0 transition-opacity duration-300 blur-xl",
              swipeDirection === "left" && "bg-destructive/20 opacity-100",
              swipeDirection === "right" && "bg-success/20 opacity-100"
            )}
          />

          <div className="relative">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-warning" />
              <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                Ситуация #{currentIndex + 1}
              </span>
            </div>

            <h2 className="text-lg font-bold mb-3">{currentScenario.title}</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {currentScenario.description}
            </p>
          </div>
        </div>

        {/* Explanation */}
        {showExplanation && (
          <div
            className={cn(
              "rounded-2xl p-5 animate-slide-up border",
              selectedAnswer === currentScenario.isScam
                ? "bg-success/10 border-success/30"
                : "bg-destructive/10 border-destructive/30"
            )}
          >
            <div className="flex items-start gap-3">
              {selectedAnswer === currentScenario.isScam ? (
                <CheckCircle className="w-6 h-6 text-success flex-shrink-0" />
              ) : (
                <X className="w-6 h-6 text-destructive flex-shrink-0" />
              )}
              <div>
                <p className="font-semibold mb-1">
                  {selectedAnswer === currentScenario.isScam ? "Правильно!" : "Неправильно"}
                </p>
                <p className="text-sm text-muted-foreground">
                  {currentScenario.explanation}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        {!showExplanation ? (
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleAnswer(false)}
              className="flex flex-col items-center gap-2 p-6 bg-card rounded-2xl border border-border/50 hover:border-success/50 transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-full bg-success/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <CheckCircle className="w-7 h-7 text-success" />
              </div>
              <span className="font-semibold">Безопасно</span>
            </button>

            <button
              onClick={() => handleAnswer(true)}
              className="flex flex-col items-center gap-2 p-6 bg-card rounded-2xl border border-border/50 hover:border-destructive/50 transition-all duration-300 group"
            >
              <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Shield className="w-7 h-7 text-destructive" />
              </div>
              <span className="font-semibold">Мошенник</span>
            </button>
          </div>
        ) : (
          <button
            onClick={nextScenario}
            className="btn-gold w-full py-4 rounded-xl flex items-center justify-center gap-2"
          >
            {currentIndex < scenarios.length - 1 ? "Следующая ситуация" : "Завершить"}
            <ChevronRight className="w-5 h-5" />
          </button>
        )}

        {/* Score */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            Правильных ответов: <span className="font-semibold text-foreground">{score}</span>
          </p>
        </div>
      </div>
    </AppLayout>
  );
};

export default AntiScam;
