import { AppLayout } from "@/components/layout/AppLayout";
import { User, Star, Trophy, BookOpen, TrendingUp, Shield, ChevronRight, Settings, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

const levels = [
  { name: "Новичок", minXP: 0, maxXP: 500 },
  { name: "Ученик", minXP: 500, maxXP: 1500 },
  { name: "Инвестор", minXP: 1500, maxXP: 3000 },
  { name: "Аналитик", minXP: 3000, maxXP: 5000 },
  { name: "Ангел-инвестор", minXP: 5000, maxXP: 10000 },
];

const achievements = [
  { icon: "🛡️", title: "Анти-скам эксперт", description: "Распознай 10 мошенников", unlocked: true },
  { icon: "📈", title: "Первый трейд", description: "Сделай первую сделку", unlocked: true },
  { icon: "💡", title: "Финансово грамотный", description: "Пройди 10 уроков", unlocked: true },
  { icon: "🔥", title: "7 дней подряд", description: "Заходи 7 дней подряд", unlocked: true },
  { icon: "🎓", title: "Магистр", description: "Пройди все уроки", unlocked: false },
  { icon: "💰", title: "Первый миллион", description: "Заработай $1M на демо", unlocked: false },
];

const Profile = () => {
  const currentXP = 1250;
  const currentLevel = levels.find((l) => currentXP >= l.minXP && currentXP < l.maxXP) || levels[0];
  const progress = ((currentXP - currentLevel.minXP) / (currentLevel.maxXP - currentLevel.minXP)) * 100;
  const xpToNext = currentLevel.maxXP - currentXP;

  return (
    <AppLayout>
      <div className="py-4 space-y-6">
        {/* Profile Header */}
        <div className="bg-card rounded-2xl p-6 border border-border/50 text-center">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-xl font-bold mb-1">Алексей</h1>
          <p className="text-sm text-muted-foreground mb-4">aleksey@example.com</p>
          
          {/* Level Badge */}
          <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 px-4 py-2 rounded-full mb-4">
            <Trophy className="w-4 h-4 text-primary" />
            <span className="font-semibold text-primary">{currentLevel.name}</span>
          </div>

          {/* XP Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Прогресс</span>
              <span className="font-semibold">{currentXP} / {currentLevel.maxXP} XP</span>
            </div>
            <div className="h-3 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-warning rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Ещё {xpToNext} XP до следующего уровня
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-card rounded-xl p-4 border border-border/50 text-center">
            <BookOpen className="w-5 h-5 text-primary mx-auto mb-2" />
            <p className="text-lg font-bold">24</p>
            <p className="text-[10px] text-muted-foreground">Уроков</p>
          </div>
          <div className="bg-card rounded-xl p-4 border border-border/50 text-center">
            <TrendingUp className="w-5 h-5 text-success mx-auto mb-2" />
            <p className="text-lg font-bold">47</p>
            <p className="text-[10px] text-muted-foreground">Сделок</p>
          </div>
          <div className="bg-card rounded-xl p-4 border border-border/50 text-center">
            <Shield className="w-5 h-5 text-destructive mx-auto mb-2" />
            <p className="text-lg font-bold">15</p>
            <p className="text-[10px] text-muted-foreground">Скамов</p>
          </div>
        </div>

        {/* Achievements */}
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-3">
            Достижения
          </h3>
          <div className="grid grid-cols-3 gap-2">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={cn(
                  "flex flex-col items-center gap-1 p-3 rounded-xl border transition-all duration-300",
                  achievement.unlocked
                    ? "bg-card border-primary/30"
                    : "bg-secondary/30 border-border/30 opacity-50"
                )}
              >
                <span className="text-2xl">{achievement.icon}</span>
                <span className="text-[9px] font-medium text-center leading-tight">
                  {achievement.title}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Level Roadmap */}
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-3">
            Уровни
          </h3>
          <div className="space-y-2">
            {levels.map((level, index) => {
              const isCompleted = currentXP >= level.maxXP;
              const isCurrent = currentXP >= level.minXP && currentXP < level.maxXP;
              
              return (
                <div
                  key={level.name}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-xl transition-all duration-300",
                    isCurrent
                      ? "bg-primary/10 border border-primary/30"
                      : isCompleted
                      ? "bg-card border border-border/50"
                      : "bg-secondary/30 border border-border/30 opacity-60"
                  )}
                >
                  <div
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold",
                      isCurrent
                        ? "bg-primary text-primary-foreground"
                        : isCompleted
                        ? "bg-success/20 text-success"
                        : "bg-secondary text-muted-foreground"
                    )}
                  >
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{level.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {level.minXP} - {level.maxXP} XP
                    </p>
                  </div>
                  {isCompleted && (
                    <Star className="w-5 h-5 text-primary" />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Settings */}
        <div className="space-y-2">
          <button className="w-full flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-colors">
            <Settings className="w-5 h-5 text-muted-foreground" />
            <span className="flex-1 text-left font-medium text-sm">Настройки</span>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </button>
          <button className="w-full flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50 hover:border-destructive/30 transition-colors text-destructive">
            <LogOut className="w-5 h-5" />
            <span className="flex-1 text-left font-medium text-sm">Выйти</span>
          </button>
        </div>
      </div>
    </AppLayout>
  );
};

export default Profile;
