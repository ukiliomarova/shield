import { AppLayout } from "@/components/layout/AppLayout";
import { DailyLessonCard } from "@/components/dashboard/DailyLessonCard";
import { StatsGrid } from "@/components/dashboard/StatsGrid";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { AchievementsRow } from "@/components/dashboard/AchievementBadge";

const Index = () => {
  return (
    <AppLayout>
      <div className="space-y-6 py-4">
        {/* Welcome */}
        <div className="animate-fade-in">
          <h1 className="text-2xl font-bold">Привет, Инвестор!</h1>
          <p className="text-sm text-muted-foreground">
            Готов к новым знаниям?
          </p>
        </div>

        {/* Daily Lesson */}
        <DailyLessonCard
          title="Что такое диверсификация?"
          description="Узнай, почему важно не класть все яйца в одну корзину и как распределить риски."
          duration="5 мин"
          progress={35}
        />

        {/* Stats */}
        <StatsGrid />

        {/* Quick Actions */}
        <QuickActions />

        {/* Achievements */}
        <AchievementsRow />

        {/* Demo disclaimer */}
        <div className="text-center py-4 animate-fade-in">
          <p className="text-[10px] text-muted-foreground/60">
            Это демо-симуляция, а не реальные деньги
          </p>
        </div>
      </div>
    </AppLayout>
  );
};

export default Index;
