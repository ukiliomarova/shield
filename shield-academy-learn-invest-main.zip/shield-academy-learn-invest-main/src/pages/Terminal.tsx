import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Wallet, History, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Asset {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change: number;
  icon: string;
  chart: number[];
}

const assets: Asset[] = [
  {
    id: "btc",
    name: "Bitcoin",
    symbol: "BTC",
    price: 67432.50,
    change: 2.34,
    icon: "₿",
    chart: [65, 68, 64, 70, 72, 69, 74, 71, 76, 73],
  },
  {
    id: "aapl",
    name: "Apple",
    symbol: "AAPL",
    price: 178.25,
    change: -0.82,
    icon: "🍎",
    chart: [180, 178, 182, 179, 176, 180, 177, 175, 178, 176],
  },
  {
    id: "tsla",
    name: "Tesla",
    symbol: "TSLA",
    price: 245.60,
    change: 5.21,
    icon: "⚡",
    chart: [230, 235, 228, 240, 238, 245, 242, 250, 248, 252],
  },
  {
    id: "googl",
    name: "Google",
    symbol: "GOOGL",
    price: 141.80,
    change: 1.15,
    icon: "🔍",
    chart: [138, 140, 139, 142, 141, 143, 140, 142, 144, 143],
  },
  {
    id: "gold",
    name: "Золото",
    symbol: "XAU",
    price: 2024.30,
    change: 0.45,
    icon: "🥇",
    chart: [2010, 2015, 2018, 2012, 2020, 2018, 2022, 2019, 2025, 2023],
  },
  {
    id: "oil",
    name: "Нефть",
    symbol: "OIL",
    price: 78.45,
    change: -1.23,
    icon: "🛢️",
    chart: [80, 79, 81, 78, 79, 77, 78, 76, 79, 77],
  },
];

function MiniChart({ data, positive }: { data: number[]; positive: boolean }) {
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min;
  
  const points = data
    .map((value, index) => {
      const x = (index / (data.length - 1)) * 60;
      const y = 20 - ((value - min) / range) * 16;
      return `${x},${y}`;
    })
    .join(" ");

  return (
    <svg width="60" height="24" className="overflow-visible">
      <polyline
        points={points}
        fill="none"
        stroke={positive ? "hsl(var(--success))" : "hsl(var(--destructive))"}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

const Terminal = () => {
  const [balance] = useState(10000);
  const [portfolio] = useState([
    { symbol: "BTC", amount: 0.05, avgPrice: 65000 },
    { symbol: "AAPL", amount: 10, avgPrice: 175 },
  ]);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [tradeAmount, setTradeAmount] = useState("");

  const portfolioValue = portfolio.reduce((sum, item) => {
    const asset = assets.find((a) => a.symbol === item.symbol);
    return sum + (asset ? asset.price * item.amount : 0);
  }, 0);

  const totalValue = balance + portfolioValue;
  const profit = totalValue - 10000;
  const profitPercent = (profit / 10000) * 100;

  return (
    <AppLayout>
      <div className="py-4 space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold">SandBox Терминал</h1>
          <p className="text-sm text-muted-foreground">
            Торгуй без риска
          </p>
        </div>

        {/* Balance Card */}
        <div className="bg-card rounded-2xl p-5 border border-border/50 card-gold-glow">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-primary" />
              <span className="text-sm text-muted-foreground">Демо-счёт</span>
            </div>
            <div
              className={cn(
                "flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium",
                profit >= 0
                  ? "bg-success/10 text-success"
                  : "bg-destructive/10 text-destructive"
              )}
            >
              {profit >= 0 ? (
                <ArrowUpRight className="w-3 h-3" />
              ) : (
                <ArrowDownRight className="w-3 h-3" />
              )}
              {profitPercent >= 0 ? "+" : ""}
              {profitPercent.toFixed(2)}%
            </div>
          </div>
          <p className="text-3xl font-bold">${totalValue.toLocaleString()}</p>
          <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
            <span>Свободно: ${balance.toLocaleString()}</span>
            <span>В активах: ${portfolioValue.toLocaleString()}</span>
          </div>
        </div>

        {/* Warning */}
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 flex items-center gap-2">
          <span className="text-lg">ℹ️</span>
          <p className="text-xs text-muted-foreground">
            Это демо-симуляция. Используются виртуальные деньги.
          </p>
        </div>

        {/* Assets List */}
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground mb-3">
            Активы
          </h3>
          <div className="space-y-2">
            {assets.map((asset) => (
              <button
                key={asset.id}
                onClick={() => setSelectedAsset(asset)}
                className="w-full flex items-center gap-3 p-4 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-all duration-300"
              >
                <span className="text-2xl">{asset.icon}</span>
                <div className="flex-1 text-left">
                  <p className="font-semibold text-sm">{asset.name}</p>
                  <p className="text-xs text-muted-foreground">{asset.symbol}</p>
                </div>
                <MiniChart data={asset.chart} positive={asset.change >= 0} />
                <div className="text-right">
                  <p className="font-semibold text-sm">
                    ${asset.price.toLocaleString()}
                  </p>
                  <p
                    className={cn(
                      "text-xs font-medium flex items-center justify-end gap-0.5",
                      asset.change >= 0 ? "text-success" : "text-destructive"
                    )}
                  >
                    {asset.change >= 0 ? (
                      <TrendingUp className="w-3 h-3" />
                    ) : (
                      <TrendingDown className="w-3 h-3" />
                    )}
                    {asset.change >= 0 ? "+" : ""}
                    {asset.change}%
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Trade Modal */}
         {selectedAsset && (
           <div 
             className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 animate-fade-in"
             onClick={() => {
               setSelectedAsset(null);
               setTradeAmount("");
             }}
           >
             <div 
               className="w-full max-w-lg bg-card rounded-t-3xl p-6 animate-slide-in-bottom"
               onClick={(e) => e.stopPropagation()}
             >
              <div className="w-12 h-1 bg-secondary rounded-full mx-auto mb-6" />
              
              <div className="flex items-center gap-3 mb-6">
                <span className="text-3xl">{selectedAsset.icon}</span>
                <div>
                  <h3 className="text-xl font-bold">{selectedAsset.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    ${selectedAsset.price.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Сумма (USD)
                  </label>
                  <input
                    type="number"
                    value={tradeAmount}
                    onChange={(e) => setTradeAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-secondary rounded-xl p-4 text-lg font-semibold outline-none focus:ring-2 focus:ring-primary"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Доступно: ${balance.toLocaleString()}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button className="btn-gold py-4 rounded-xl font-semibold">
                    Купить
                  </button>
                  <button className="bg-secondary hover:bg-secondary/80 py-4 rounded-xl font-semibold transition-colors">
                    Продать
                  </button>
                </div>

                <button
                  onClick={() => {
                    setSelectedAsset(null);
                    setTradeAmount("");
                  }}
                  className="w-full py-3 text-sm text-muted-foreground"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* History Link */}
        <button className="w-full flex items-center justify-between p-4 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-colors">
          <div className="flex items-center gap-3">
            <History className="w-5 h-5 text-muted-foreground" />
            <span className="font-medium text-sm">История сделок</span>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>
    </AppLayout>
  );
};

export default Terminal;
