import { Shield, Star, User } from "lucide-react";
import { Link } from "react-router-dom";

interface HeaderProps {
  xp: number;
  level: string;
}

export function Header({ xp, level }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-border/50">
      <div className="flex items-center justify-between px-4 py-3 max-w-lg mx-auto">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="relative">
            <Shield className="w-8 h-8 text-primary" />
            <div className="absolute inset-0 bg-primary/20 blur-lg rounded-full" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-gradient-gold">SHIELD</span>
            <span className="text-[10px] text-muted-foreground -mt-1">Academy</span>
          </div>
        </Link>

        {/* Stats */}
        <div className="flex items-center gap-3">
          {/* XP */}
          <div className="flex items-center gap-1.5 bg-secondary/80 px-3 py-1.5 rounded-full">
            <Star className="w-4 h-4 text-primary" />
            <span className="text-xs font-semibold">{xp} XP</span>
          </div>

          {/* Level Badge */}
          <div className="bg-primary/10 border border-primary/30 px-2 py-1 rounded-lg">
            <span className="text-[10px] font-medium text-primary">{level}</span>
          </div>

          {/* Profile */}
          <Link
            to="/profile"
            className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
          >
            <User className="w-4 h-4 text-muted-foreground" />
          </Link>
        </div>
      </div>
    </header>
  );
}
