import { cn } from "@/lib/utils";

interface AchievementBadgeProps {
  icon: string;
  title: string;
  unlocked: boolean;
}

export function AchievementBadge({ icon, title, unlocked }: AchievementBadgeProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-2 p-3 rounded-xl transition-all duration-300",
        unlocked
          ? "bg-primary/10 border border-primary/30"
          : "bg-secondary/50 border border-border/30 opacity-50"
      )}
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-[10px] font-medium text-center leading-tight">
        {title}
      </span>
    </div>
  );
}

export function AchievementsRow() {
  const achievements = [
    { icon: "🛡️", title: "Анти-скам эксперт", unlocked: true },
    { icon: "📈", title: "Первый трейд", unlocked: true },
    { icon: "💡", title: "Финансово грамотный", unlocked: true },
    { icon: "🔥", title: "7 дней подряд", unlocked: true },
    { icon: "🎓", title: "Магистр", unlocked: false },
  ];

  return (
    <div className="animate-slide-up" style={{ animationDelay: "0.3s" }}>
      <h3 className="text-sm font-semibold text-muted-foreground mb-3">
        Достижения
      </h3>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
        {achievements.map((achievement, index) => (
          <AchievementBadge key={index} {...achievement} />
        ))}
      </div>
    </div>
  );
}
