import { BookOpen, Clock, ChevronRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

interface DailyLessonCardProps {
  title: string;
  description: string;
  duration: string;
  progress: number;
  isCompleted?: boolean;
}

export function DailyLessonCard({
  title,
  description,
  duration,
  progress,
  isCompleted = false,
}: DailyLessonCardProps) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-card border border-border/50 card-gold-glow animate-slide-up">
      {/* Glow effect */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-primary/10 rounded-full blur-3xl" />
      
      <div className="relative p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary" />
            </div>
            <div>
              <span className="text-[10px] uppercase tracking-wider text-primary font-semibold">
                Сегодняшний урок
              </span>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>{duration}</span>
              </div>
            </div>
          </div>
          {isCompleted && (
            <div className="flex items-center gap-1 bg-success/10 text-success px-2 py-1 rounded-full">
              <Sparkles className="w-3 h-3" />
              <span className="text-[10px] font-medium">Завершено</span>
            </div>
          )}
        </div>

        {/* Content */}
        <h3 className="text-lg font-bold mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {description}
        </p>

        {/* Progress bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-muted-foreground">Прогресс</span>
            <span className="font-medium">{progress}%</span>
          </div>
          <div className="h-2 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-primary to-warning rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* CTA Button */}
        <Link
          to="/learning"
          className="btn-gold w-full flex items-center justify-center gap-2 py-3 rounded-xl"
        >
          <span>{progress > 0 ? "Продолжить обучение" : "Начать обучение"}</span>
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
