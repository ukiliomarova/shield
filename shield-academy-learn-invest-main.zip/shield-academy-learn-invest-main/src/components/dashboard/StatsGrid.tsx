import { TrendingUp, Shield, Target, Flame } from "lucide-react";

interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: string | number;
  change?: string;
  positive?: boolean;
}

function StatCard({ icon: Icon, label, value, change, positive }: StatCardProps) {
  return (
    <div className="bg-card rounded-xl p-4 border border-border/50 hover:border-primary/30 transition-colors duration-300">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-4 h-4 text-primary" />
        </div>
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <div className="flex items-center justify-between mt-1">
        <span className="text-xs text-muted-foreground">{label}</span>
        {change && (
          <span
            className={`text-xs font-medium ${
              positive ? "text-success" : "text-destructive"
            }`}
          >
            {change}
          </span>
        )}
      </div>
    </div>
  );
}

export function StatsGrid() {
  return (
    <div className="grid grid-cols-2 gap-3 animate-slide-up" style={{ animationDelay: "0.1s" }}>
      <StatCard
        icon={Flame}
        label="Дней подряд"
        value={7}
        change="+1"
        positive
      />
      <StatCard
        icon={Target}
        label="Уроков пройдено"
        value={24}
        change="+3"
        positive
      />
      <StatCard
        icon={TrendingUp}
        label="Демо-прибыль"
        value="+12.5%"
        positive
      />
      <StatCard
        icon={Shield}
        label="Скамы раскрыты"
        value={15}
        change="+5"
        positive
      />
    </div>
  );
}
