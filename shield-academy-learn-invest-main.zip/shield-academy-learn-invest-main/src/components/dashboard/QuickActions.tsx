import { TrendingUp, Bot, Shield, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";

const actions = [
  {
    icon: TrendingUp,
    label: "Терминал",
    description: "Торговый симулятор",
    path: "/terminal",
    color: "text-success",
    bg: "bg-success/10",
  },
  {
    icon: Bot,
    label: "AI Shieldy",
    description: "Задай вопрос",
    path: "/ai-chat",
    color: "text-primary",
    bg: "bg-primary/10",
  },
  {
    icon: Shield,
    label: "Anti-Scam",
    description: "Распознай скам",
    path: "/anti-scam",
    color: "text-destructive",
    bg: "bg-destructive/10",
  },
];

export function QuickActions() {
  return (
    <div className="space-y-2 animate-slide-up" style={{ animationDelay: "0.2s" }}>
      <h3 className="text-sm font-semibold text-muted-foreground mb-3">
        Быстрый доступ
      </h3>
      <div className="space-y-2">
        {actions.map((action) => (
          <Link
            key={action.path}
            to={action.path}
            className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/50 hover:border-primary/30 transition-all duration-300 group"
          >
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", action.bg)}>
              <action.icon className={cn("w-5 h-5", action.color)} />
            </div>
            <div className="flex-1">
              <p className="font-medium text-sm">{action.label}</p>
              <p className="text-xs text-muted-foreground">{action.description}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
          </Link>
        ))}
      </div>
    </div>
  );
}
